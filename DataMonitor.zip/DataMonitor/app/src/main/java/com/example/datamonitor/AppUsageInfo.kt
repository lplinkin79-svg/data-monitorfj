package com.example.datamonitor

/**
 * Menyimpan hasil rekap pemakaian data untuk satu aplikasi
 * dalam satu periode (hari / bulan) dan satu jenis jaringan (WIFI / MOBILE).
 */
data class AppUsageInfo(
    val uid: Int,
    val packageName: String,
    val appName: String,
    var foregroundRxBytes: Long = 0,
    var foregroundTxBytes: Long = 0,
    var backgroundRxBytes: Long = 0,
    var backgroundTxBytes: Long = 0
) {
    val foregroundTotal: Long get() = foregroundRxBytes + foregroundTxBytes
    val backgroundTotal: Long get() = backgroundRxBytes + backgroundTxBytes
    val total: Long get() = foregroundTotal + backgroundTotal
}

/** Ringkasan total perangkat, dipakai untuk menghitung estimasi trafik hotspot. */
data class DeviceTotal(
    val rxBytes: Long,
    val txBytes: Long
) {
    val total: Long get() = rxBytes + txBytes
}

/** Hasil akhir satu query: daftar per-app + pemakaian hotspot (tethering). */
data class UsageReport(
    val periodLabel: String,
    val apps: List<AppUsageInfo>,
    val deviceTotalBytes: Long,
    val ownAppsTotalBytes: Long,
    val tetheringBytes: Long = 0L
) {
    /** Cadangan (fallback) kalau sistem tidak mencatat UID tethering khusus:
     *  perkiraan dari selisih total perangkat - total semua aplikasi. */
    val estimatedHotspotBytes: Long
        get() = if (tetheringBytes > 0) tetheringBytes
                else (deviceTotalBytes - ownAppsTotalBytes).coerceAtLeast(0)
}
