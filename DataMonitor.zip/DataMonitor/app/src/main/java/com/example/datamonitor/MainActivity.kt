package com.example.datamonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DataMonitorScreen()
                }
            }
        }
    }
}

@Composable
fun DataMonitorScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val helper = remember { NetworkStatsHelper(context) }

    var hasAccess by remember { mutableStateOf(helper.hasUsageAccess()) }
    var netType by remember { mutableStateOf(NetType.MOBILE) }
    var period by remember { mutableStateOf(Period.DAILY) }
    var report by remember { mutableStateOf<UsageReport?>(null) }
    var refreshTick by remember { mutableStateOf(0) }

    // Re-cek izin tiap kali layar kembali terlihat (setelah user pulang dari Settings)
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                hasAccess = helper.hasUsageAccess()
                refreshTick++ // otomatis muat ulang data tiap kali app dibuka/kembali ke depan
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasAccess, netType, period, refreshTick) {
        if (hasAccess) {
            report = null // tampilkan loading dulu biar kelihatan lagi memuat ulang
            report = helper.queryUsage(netType, period)
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Monitor Pemakaian Data", style = MaterialTheme.typography.headlineSmall)
            IconButton(onClick = { refreshTick++ }) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = "Muat ulang"
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        if (!hasAccess) {
            Text(
                "Aplikasi butuh izin \"Usage access\" untuk membaca statistik data. " +
                    "Aktifkan lalu kembali ke aplikasi ini.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { helper.openUsageAccessSettings() }) {
                Text("Buka Pengaturan")
            }
            return@Column
        }

        // --- Pilihan jaringan ---
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipRow(
                selected = netType == NetType.MOBILE,
                label = "Seluler",
                onClick = { netType = NetType.MOBILE }
            )
            FilterChipRow(
                selected = netType == NetType.WIFI,
                label = "Wi-Fi",
                onClick = { netType = NetType.WIFI }
            )
        }
        Spacer(Modifier.height(8.dp))

        // --- Pilihan periode ---
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipRow(
                selected = period == Period.DAILY,
                label = "Per Hari",
                onClick = { period = Period.DAILY }
            )
            FilterChipRow(
                selected = period == Period.MONTHLY,
                label = "Per Bulan",
                onClick = { period = Period.MONTHLY }
            )
        }

        Spacer(Modifier.height(16.dp))

        report?.let { r ->
            SummaryCard(r)
            Spacer(Modifier.height(12.dp))
            Text("Rincian per Aplikasi", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(r.apps) { app -> AppRow(app) }
            }
        } ?: run {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
    }
}

@Composable
fun FilterChipRow(selected: Boolean, label: String, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
fun SummaryCard(report: UsageReport) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(report.periodLabel, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total perangkat")
                Text(formatBytes(report.deviceTotalBytes))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pemakaian aplikasi sendiri")
                Text(formatBytes(report.ownAppsTotalBytes))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Estimasi Hotspot/Tethering")
                Text(formatBytes(report.estimatedHotspotBytes))
            }
            Text(
                "*Estimasi hotspot dihitung dari selisih total perangkat dan total semua " +
                    "aplikasi, karena Android tidak memberi rincian per perangkat yang tersambung.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun AppRow(app: AppUsageInfo) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(app.appName, fontWeight = FontWeight.SemiBold)
                Text(formatBytes(app.total))
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Layar depan: ${formatBytes(app.foregroundTotal)}",
                    style = MaterialTheme.typography.bodySmall)
                Text("Layar belakang: ${formatBytes(app.backgroundTotal)}",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
