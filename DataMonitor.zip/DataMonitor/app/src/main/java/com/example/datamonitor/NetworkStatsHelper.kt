package com.example.datamonitor

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Process
import android.provider.Settings
import java.util.Calendar

enum class NetType(val platformType: Int) {
    MOBILE(ConnectivityManager.TYPE_MOBILE),
    WIFI(ConnectivityManager.TYPE_WIFI)
}

enum class Period { DAILY, MONTHLY }

class NetworkStatsHelper(private val context: Context) {

    private val statsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    private val pm = context.packageManager

    /** Cek apakah user sudah memberi izin "Usage access" (wajib untuk NetworkStatsManager). */
    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Arahkan user ke halaman pengaturan untuk mengaktifkan izin Usage access. */
    fun openUsageAccessSettings() {
        val intent = android.content.Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun periodRange(period: Period): Pair<Long, Long> {
        val end = Calendar.getInstance()
        val start = Calendar.getInstance()
        when (period) {
            Period.DAILY -> {
                start.set(Calendar.HOUR_OF_DAY, 0)
                start.set(Calendar.MINUTE, 0)
                start.set(Calendar.SECOND, 0)
                start.set(Calendar.MILLISECOND, 0)
            }
            Period.MONTHLY -> {
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0)
                start.set(Calendar.MINUTE, 0)
                start.set(Calendar.SECOND, 0)
                start.set(Calendar.MILLISECOND, 0)
            }
        }
        return start.timeInMillis to end.timeInMillis
    }

    /**
     * Ambil rekap pemakaian data per aplikasi untuk satu jenis jaringan + periode.
     * subscriberId dikosongkan (null) -> mencocokkan semua subscriber, ini yang
     * paling kompatibel lintas device untuk MOBILE maupun WIFI.
     */
    @Suppress("DEPRECATION")
    fun queryUsage(netType: NetType, period: Period): UsageReport {
        val (start, end) = periodRange(period)
        val appMap = LinkedHashMap<Int, AppUsageInfo>()

        var ownAppsTotal = 0L

        try {
            val bucket = NetworkStats.Bucket()
            val stats: NetworkStats = statsManager.querySummary(
                netType.platformType, null, start, end
            )
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                val uid = bucket.uid

                // Lewati uid sistem khusus (removed apps, tethering, dll) dari daftar per-app,
                // tapi tetap dihitung ke total perangkat lewat querySummaryForDevice.
                val info = appMap.getOrPut(uid) {
                    val (name, pkg) = resolveAppName(uid)
                    AppUsageInfo(uid = uid, packageName = pkg, appName = name)
                }

                val isForeground = bucket.state == NetworkStats.Bucket.STATE_FOREGROUND
                if (isForeground) {
                    info.foregroundRxBytes += bucket.rxBytes
                    info.foregroundTxBytes += bucket.txBytes
                } else {
                    info.backgroundRxBytes += bucket.rxBytes
                    info.backgroundTxBytes += bucket.txBytes
                }
                ownAppsTotal += bucket.rxBytes + bucket.txBytes
            }
            stats.close()
        } catch (e: SecurityException) {
            // Izin usage access belum aktif
        }

        val deviceTotal = try {
            val devBucket = statsManager.querySummaryForDevice(
                netType.platformType, null, start, end
            )
            devBucket.rxBytes + devBucket.txBytes
        } catch (e: Exception) {
            ownAppsTotal
        }

        val label = if (period == Period.DAILY) "Hari ini" else "Bulan ini"
        return UsageReport(
            periodLabel = label,
            apps = appMap.values.sortedByDescending { it.total }.filter { it.total > 0 },
            deviceTotalBytes = deviceTotal,
            ownAppsTotalBytes = ownAppsTotal
        )
    }

    private fun resolveAppName(uid: Int): Pair<String, String> {
        val packages = pm.getPackagesForUid(uid)
        if (packages.isNullOrEmpty()) {
            return "UID $uid (sistem/lainnya)" to "uid:$uid"
        }
        val pkg = packages[0]
        val label = try {
            val ai = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(ai).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            pkg
        }
        return label to pkg
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.1f MB".format(mb)
    val gb = mb / 1024.0
    return "%.2f GB".format(gb)
}
