# Data Monitor (Android Native – Kotlin + Jetpack Compose)

Aplikasi pemantau pemakaian data internet per aplikasi.

## Fitur yang sudah diimplementasikan

1. **Monitor data per aplikasi** — memakai `NetworkStatsManager` bawaan Android,
   menampilkan pemakaian tiap app yang pernah terpakai jaringan.
2. **Per hari & per bulan** — tombol switch periode (`DAILY` / `MONTHLY`).
3. **Layar depan vs layar belakang** — Android mencatat state `STATE_FOREGROUND`
   dan `STATE_DEFAULT` (background) di tiap bucket data, sudah dipisahkan di UI.
4. **Estimasi pemakaian Hotspot vs aplikasi sendiri** — lihat bagian "Batasan" di bawah,
   karena ini **tidak** didukung penuh oleh Android secara publik.

## Cara build

1. Buka folder ini dengan **Android Studio** (Hedgehog/Koala ke atas).
2. Biarkan Gradle sync otomatis (butuh internet saat sync pertama untuk
   mengunduh dependency).
3. Jalankan ke device/emulator fisik — **fitur ini tidak bisa diuji penuh di
   emulator** karena butuh trafik data seluler/Wi-Fi nyata.
4. Saat pertama dibuka, app akan minta izin **"Usage access"**
   (`Settings > Apps > Special access > Usage access`) — ini wajib,
   tidak bisa lewat dialog izin biasa karena termasuk *special permission*.

## Batasan penting (harus dipahami)

- **Rincian hotspot per perangkat lain TIDAK tersedia di Android tanpa root.**
  Android hanya mencatat data yang dipakai oleh *aplikasi* (per UID). Trafik yang
  numpang lewat hotspot/tethering ke HP/laptop lain **tidak** tercatat atas nama
  aplikasi manapun — jadi tidak mungkin dipecah "device A pakai sekian MB,
  device B pakai sekian MB" tanpa akses root atau custom ROM.
  Yang aplikasi ini lakukan: menghitung **total pemakaian perangkat**
  (`querySummaryForDevice`) dikurangi **total semua aplikasi**
  (`querySummary` per UID) → sisanya diasumsikan sebagai trafik tethering/hotspot.
  Ini estimasi, bukan angka pasti.
- Untuk breakdown *per perangkat yang tersambung ke hotspot* secara akurat,
  satu-satunya cara adalah bikin custom router/hotspot software sendiri
  (mis. pakai `VpnService` + baca tabel koneksi, atau root + `iptables` logging)
  — ini di luar cakupan API publik Android dan butuh proyek terpisah yang jauh
  lebih kompleks (dan biasanya butuh device rooted).
- Query MOBILE data (`NetType.MOBILE`) di beberapa vendor HP kadang butuh
  `subscriberId` yang sesuai SIM aktif; kode ini memakai `null` (match semua
  subscriber) yang umumnya bekerja saat izin *Usage access* sudah aktif, tapi
  perilakunya bisa sedikit beda antar merk HP (Xiaomi/Samsung/dll kadang extra
  restriktif di App Ops mereka sendiri).
- Icon aplikasi masih pakai icon sistem default (`sym_def_app_icon`) supaya
  proyek langsung bisa di-build tanpa aset tambahan — ganti dengan launcher
  icon sendiri di Android Studio (`New > Image Asset`).

## Struktur

```
app/src/main/java/com/example/datamonitor/
  MainActivity.kt          -> UI (Jetpack Compose)
  NetworkStatsHelper.kt     -> logic query NetworkStatsManager
  AppUsageInfo.kt           -> model data
```

## Saran pengembangan lanjut

- Tambahkan `Room` database untuk menyimpan histori harian (NetworkStatsManager
  hanya menyimpan data mundur sekitar 30-90 hari tergantung device).
- Tambahkan grafik (mis. pakai `Vico` atau `MPAndroidChart`) untuk tren per hari
  dalam sebulan.
- Tambahkan `WorkManager` job harian untuk snapshot data agar histori tidak
  hilang meski data OS di-reset.
